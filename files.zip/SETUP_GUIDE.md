# Rightway Academy — CMS Setup Guide
# Complete step-by-step instructions

## Files in this folder
- admin/index.html    → The CMS interface (lives at rightwayacademy.pk/admin)
- admin/config.yml    → Tells CMS what fields to edit on your website
- netlify.toml        → Netlify build settings (IMPORTANT)
- SETUP_GUIDE.md      → This file

---

## STEP 1 — Create GitHub account & repository

1. Go to https://github.com → Sign Up (free)
2. Click the green "New" button to create a repository
3. Name: rightway-academy
4. Set to Public
5. Click "Create repository"

---

## STEP 2 — Upload your website files to GitHub

In your new repository, click "uploading an existing file"

Upload these files:
- index.html          (your main website — rename from rightway_academy_v3.html)
- netlify.toml        (from this folder)
- admin/              (the entire admin folder with index.html and config.yml)

Click "Commit changes" (green button at the bottom)

---

## STEP 3 — Connect GitHub to Netlify

1. Go to https://app.netlify.com → Log in / Sign up
2. Click "Add new site" → "Import an existing project"
3. Choose "Deploy with GitHub"
4. Select your "rightway-academy" repository
5. Build settings:
   - Build command: LEAVE EMPTY (delete anything there)
   - Publish directory: . (just a dot, meaning root folder)
6. Click "Deploy site"
7. Your site will be live in ~1 minute

---

## STEP 4 — Connect your custom domain

1. In Netlify → Site settings → Domain management
2. Add custom domain: rightwayacademy.pk
3. Follow DNS instructions to point your domain to Netlify
4. Netlify gives free SSL automatically

---

## STEP 5 — Enable Netlify Identity (your CMS login)

1. In Netlify → Site settings → Identity → Enable Identity
2. Under Registration: change to "Invite only"
3. Under Git Gateway: Enable Git Gateway (this is what lets CMS save to GitHub)
4. Go to Identity tab → Invite users → enter your email
5. Check your email and accept the invitation → set your password

---

## STEP 6 — Open your CMS!

Go to: https://www.rightwayacademy.pk/admin

Log in with the email and password you set in Step 5.

You will see:
- Site settings → edit phone, email, links, stats
- Announcements → edit the ticker and BISE alert
- Blog posts → write new posts, edit existing
- FAQ → add/edit/delete questions
- Courses → edit course descriptions
- Faculty → manage teacher profiles

Every time you click "Publish" in the CMS:
✅ GitHub gets updated automatically
✅ Netlify detects the change
✅ Your website rebuilds (takes ~30 seconds)
✅ Students see the updated page

---

## IMPORTANT: Why it failed before

The most common reason Netlify deployment fails with a GitHub-connected HTML site:

WRONG settings:
  Build command: npm run build    ← This fails! There is no npm project.
  Publish directory: /dist        ← This fails! There is no dist folder.

CORRECT settings:
  Build command: (empty — delete everything)
  Publish directory: . (just a dot)

---

## STEP 7 (Optional) — Google Sheets for forms

To receive enrollment and MCQ data in Google Sheets:
1. Go to script.google.com → New project
2. Paste the Apps Script code (ask Claude to generate it)
3. Deploy → Web app → Anyone → Copy URL
4. In CMS → Site settings → SEO/Google → paste the URL in "Google Sheets Script URL"

---

## Help

WhatsApp: 0303-4263823
Email: touseefazam33@gmail.com
